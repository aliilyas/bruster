#!/usr/bin/env bash
set -euo pipefail
source /home/admin/Projects/.bruster-build/env.sh
ROOT="$PWD/benchmarks/results/implementation"
OUT="$ROOT/clean-2026-11-05"
HARNESS="$OUT/harness-main/scripts"
DEPS="$ROOT/deps-2026-11-05"
source "$DEPS/browser-paths.env"
export CARGO_TARGET_DIR="$PWD/target"
export BENCH_OUT="$OUT" BENCH_DEPS="$DEPS" BENCH_ROOT="$ROOT"
python3 -B "$OUT/preflight.py"
python3 -B "$OUT/quiet-machine.py"
unset DISPLAY WAYLAND_DISPLAY BRUSTER_TRACE_NAV BRUSTER_TEST_STDERR
for workload in startup graphics transport timers; do
  rounds=3
  if [ "$workload" = startup ]; then rounds=20; fi
  if [ "$workload" = timers ]; then rounds=1; fi
  bwrap --dev-bind / / --overlay-src /usr --overlay-src "$BRUSTER_DEPS/usr" --ro-overlay /usr \
    python3 -B "$HARNESS/bench_performance.py" --baseline "$ROOT/baseline-bruster" \
    --candidate "$ROOT/final/candidate-bruster-d4c56d9" --workload "$workload" --rounds "$rounds" \
    --output "$OUT/paired-$workload.json" > "$OUT/paired-$workload.log" 2>&1
done
bwrap --dev-bind / / --overlay-src /usr --overlay-src "$BRUSTER_DEPS/usr" --ro-overlay /usr \
  xvfb-run -a -s '-screen 0 1280x1024x24 -nolisten tcp -extension GLX' \
  python3 -B "$HARNESS/bench_compare.py" --bruster "$ROOT/final/candidate-bruster-d4c56d9" \
  --node "$(command -v node)" --chrome "$BENCH_CHROME" --shell "$BENCH_SHELL" --deps "$DEPS" \
  --tools bruster playwright puppeteer agent-browser playwright-shell \
  --rounds 5 --iterations 10 --output "$OUT/compare-candidate" > "$OUT/compare-candidate.log" 2>&1
bwrap --dev-bind / / --overlay-src /usr --overlay-src "$BRUSTER_DEPS/usr" --ro-overlay /usr \
  xvfb-run -a python3 -B "$HARNESS/bench_compare.py" --bruster "$ROOT/baseline-bruster" \
  --node "$(command -v node)" --chrome "$BENCH_CHROME" --shell "$BENCH_SHELL" --deps "$DEPS" \
  --rounds 5 --iterations 10 --tools bruster --output "$OUT/compare-baseline" > "$OUT/compare-baseline.log" 2>&1
for version in candidate baseline; do
  binary="$ROOT/final/candidate-bruster-d4c56d9"
  if [ "$version" = baseline ]; then binary="$ROOT/baseline-bruster"; fi
  bwrap --dev-bind / / --overlay-src /usr --overlay-src "$BRUSTER_DEPS/usr" --ro-overlay /usr \
    python3 -B "$HARNESS/bench_footprint.py" --bruster "$binary" --node "$(command -v node)" \
    --chrome "$BENCH_CHROME" --shell "$BENCH_SHELL" --deps "$DEPS" \
    --samples "$OUT/compare-$version/samples.json" --output "$OUT/footprint-$version.json" \
    > "$OUT/footprint-$version.log" 2>&1
done
PYTHONPATH="$HARNESS" python3 -B "$OUT/validate.py"
