#!/usr/bin/env python3
"""Targeted Linux experiments; run one workload at a time under Xvfb.

Prototype switches require benchmarks/experiments/deep-dive.patch. Results are
diagnostics, not input to the published cross-tool benchmark. No cache flushing.
"""
import argparse
import ctypes
import hashlib
import json
import os
import platform
import queue
import statistics
import subprocess
import tempfile
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

import bench_audit as audit
import bench_compare as compare


class Fixtures(audit.Fixtures):
    def do_GET(self):
        self.server.arrivals.append((self.path, time.perf_counter_ns()))
        super().do_GET()


class MCPClient(compare.ProcessClient):
    def __init__(self, binary):
        self.timeout, self.close_error = 60, None
        self.events, self.stderr, self.next_id = queue.Queue(), [], 0
        self.temp = tempfile.TemporaryDirectory(prefix='bruster-deep-mcp-')
        self.started_ns = time.perf_counter_ns()
        self.proc = subprocess.Popen([str(binary), '--mcp'], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, env=compare.isolated_environment(self.temp.name, False), start_new_session=True)
        self.reader = threading.Thread(target=self._read, daemon=True)
        self.err_reader = threading.Thread(target=self._read_errors, daemon=True)
        self.reader.start()
        self.err_reader.start()
        self.proc.stdin.write(b'{"jsonrpc":"2.0","id":0,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"probe","version":"1"}}}\n')
        self.proc.stdin.flush()
        stamp, self.ready, _ = self.wait(lambda o: o.get('id') == 0)
        self.startup_ms = (stamp - self.started_ns) / 1e6
        self.proc.stdin.write(b'{"jsonrpc":"2.0","method":"notifications/initialized"}\n')
        self.proc.stdin.flush()

    def call(self, method, params=None):
        self.next_id += 1
        request_id = self.next_id
        raw = json.dumps({'jsonrpc': '2.0', 'id': request_id, 'method': 'tools/call',
                          'params': {'name': method, 'arguments': params or {}}}, separators=(',', ':')).encode() + b'\n'
        start = time.perf_counter_ns()
        self.proc.stdin.write(raw)
        self.proc.stdin.flush()
        stamp, reply, size = self.wait(lambda o: o.get('id') == request_id)
        if 'error' in reply or reply.get('result', {}).get('isError'):
            raise RuntimeError(str(reply))
        text = reply['result']['content'][0]['text']
        # The MCP text wire format loses the distinction between JSON strings
        # and objects. Keep eval output as text and normalize it at validation.
        result = text if method == 'eval' else json.loads(text)
        return (stamp - start) / 1e6, result, size


@contextmanager
def environment(values):
    old = {key: os.environ.get(key) for key in values}
    try:
        for key, value in values.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        yield
    finally:
        for key, value in old.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def process_status(pid):
    status = dict(line.split(':', 1) for line in Path(f'/proc/{pid}/status').read_text().splitlines())
    return {key: int(status[key].split()[0]) for key in ('Threads', 'VmSize', 'VmRSS', 'VmData')}


def sample_memory(before, pid):
    result = compare.memory_forest(before, True)
    result['parent_status'] = process_status(pid)
    return result


def save(args, rows, server):
    metadata = {
        'recorded_utc': datetime.now(timezone.utc).isoformat(),
        'platform': platform.platform(), 'os': platform.freedesktop_os_release(),
        'cpu': next(line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),
        'baseline_sha256': hashlib.sha256(args.baseline.read_bytes()).hexdigest(),
        'prototype_sha256': hashlib.sha256(args.prototype.read_bytes()).hexdigest(),
        'display': os.environ.get('DISPLAY'), 'environment': {k: v for k, v in os.environ.items() if k.startswith(('GDK_', 'WEBKIT_', 'BRUSTER_DEEP', '__EGL_', 'LIBGL_', 'GALLIUM_'))},
        'rounds': 1 if args.workload == 'timers' else args.rounds, 'workload': args.workload,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({'metadata': metadata, 'rows': rows, 'arrivals': server.arrivals}, indent=2) + '\n')


def navigation(args, server):
    rows = []
    base = f'http://127.0.0.1:{server.server_port}'
    modes = ['baseline', 'instrumented', 'none', 'after-trim', 'direct', 'prewait600']
    if args.modes:
        modes = args.modes.split(',')
    for round_ in range(args.rounds):
        order = modes[round_ % len(modes):] + modes[:round_ % len(modes)]
        for mode in order:
            url = f'{base}/tiny?mode={mode}&round={round_}'
            before = compare.process_table()
            row = {'mode': mode, 'round': round_ + 1}
            env = {'BRUSTER_DEEP_TRACE': '1', 'BRUSTER_DEEP_INITIAL': mode,
                   'BRUSTER_DEEP_URL': url if mode == 'direct' else None,
                   'BRUSTER_DEEP_PAINT': '1' if mode == 'defer-paint' else None}
            with environment(env):
                client = compare.ProcessClient([str(args.baseline if mode in ('baseline', 'prewait600') else args.prototype), '--hidden'], False)
                try:
                    row['startup_ms'] = client.startup_ms
                    if mode == 'prewait600':
                        time.sleep(0.6)
                    row['sent_ns'] = time.perf_counter_ns()
                    row['started_ns'] = client.started_ns
                    if mode == 'direct':
                        stamp, _, _ = client.wait(lambda o: o.get('event') == 'load' and o.get('url') == url)
                        row['first_navigation_ms'] = (stamp - row['sent_ns']) / 1e6
                    else:
                        row['first_navigation_ms'] = client.navigate(url)
                    row['total_ms'] = (time.perf_counter_ns() - client.started_ns) / 1e6
                    arrival, = [stamp for path, stamp in server.arrivals if path == url.split(str(server.server_port), 1)[1]]
                    row['send_to_server_ms'] = (arrival - row['sent_ns']) / 1e6
                    _, result, _ = client.call('eval', {'expression': '({state:document.readyState,title:document.title,nav:performance.getEntriesByType("navigation")[0].toJSON()})'})
                    assert result['state'] == 'complete' and result['title'] == 'bench', result
                    row['page_timing'] = result['nav']
                    row['warm_ms'] = [client.navigate(url + f'&warm={i}') for i in range(3)]
                except Exception as exc:
                    row['error'] = str(exc)
                finally:
                    owned = compare.owned_processes(before)
                    client.close()
                    row['stderr'] = client.stderr
                    row['close_error'] = client.close_error
                    row['forced_cleanup'] = compare.cleanup(owned)
            rows.append(row)
            save(args, rows, server)
            print({k: v for k, v in row.items() if k.endswith('_ms') or k in ('mode', 'round', 'error')}, flush=True)
    return rows


def graphics(args, server):
    rows = []
    base = f'http://127.0.0.1:{server.server_port}'
    for round_ in range(args.rounds):
        before = compare.process_table()
        client = compare.ProcessClient([str(args.prototype if args.modes == 'prototype' else args.baseline), '--hidden'], False)
        row = {'round': round_ + 1, 'startup_ms': client.startup_ms}
        try:
            row['first_navigation_ms'] = client.navigate(f'{base}/tiny?round={round_}')
            row['total_ms'] = (time.perf_counter_ns() - client.started_ns) / 1e6
            client.navigate(f'{base}/large')
            _, result, _ = client.call('eval', {'expression': compare.EXTRACT})
            compare.validate_extract(result, 2000, 'large')
            row['extract_sha256'] = hashlib.sha256(json.dumps(result, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
            image = args.output.with_suffix(f'.{round_}.png')
            row['screenshot_ms'], _, _ = client.call('screenshot', {'path': str(image)})
            row['png_sha256'] = hashlib.sha256(image.read_bytes()).hexdigest()
            row['png_bytes'] = image.stat().st_size
            time.sleep(1)
            row['memory'] = sample_memory(before, client.proc.pid)
            assert row['memory']['complete']
            paths = {p for proc in row['memory']['processes'] + row['memory']['display'] for p in proc['mapped_files']}
            row['mapped_inventory'] = [{'path': p, 'bytes': Path(p).stat().st_size} for p in sorted(paths) if Path(p).is_file()]
        except Exception as exc:
            row['error'] = str(exc)
        finally:
            owned = compare.owned_processes(before)
            client.close()
            row['stderr'] = client.stderr
            row['close_error'] = client.close_error
            row['forced_cleanup'] = compare.cleanup(owned)
        rows.append(row)
        save(args, rows, server)
        print({k: row.get(k) for k in ('round', 'total_ms', 'png_sha256', 'error')}, 'PSS', row.get('memory', {}).get('total_pss_mib'), flush=True)
    return rows


def timers(args, server):
    rows = []
    base = f'http://127.0.0.1:{server.server_port}'
    for mode in (args.modes or 'baseline,prototype').split(','):
        before = compare.process_table()
        with environment({'BRUSTER_DEEP_TIMER': '1' if mode == 'prototype' else None}):
            client = compare.ProcessClient([str(args.prototype if mode == 'prototype' else args.baseline), '--hidden'], False)
        row = {'mode': mode, 'samples': [], 'navigation_ms': []}
        try:
            client.navigate(f'{base}/tiny?warmup')
            start = time.monotonic()
            for i in range(201):
                if i % 50 == 0:
                    row['samples'].append({'completed': i, 'elapsed_s': time.monotonic() - start, 'memory': sample_memory(before, client.proc.pid)})
                if i < 200:
                    row['navigation_ms'].append(client.navigate(f'{base}/tiny?i={i}'))
            time.sleep(31)
            row['samples'].append({'completed': 200, 'elapsed_s': time.monotonic() - start, 'after_timeout_window': True, 'memory': sample_memory(before, client.proc.pid)})
            _, title, _ = client.call('eval', {'expression': 'document.title'})
            assert title == 'bench'
        finally:
            owned = compare.owned_processes(before)
            client.close()
            row['stderr'] = client.stderr
            row['forced_cleanup'] = compare.cleanup(owned)
        rows.append(row)
        save(args, rows, server)
        print(mode, [(s['completed'], s['memory']['parent_status'], s['memory']['total_pss_mib']) for s in row['samples']], flush=True)
    return rows


def extraction(args, server):
    rows = []
    base = f'http://127.0.0.1:{server.server_port}'
    modes = (args.modes or 'baseline,raw,mcp,playwright-shell,playwright,puppeteer,agent-browser').split(',')
    payload_dir = args.output.parent / 'payloads'
    payload_dir.mkdir(exist_ok=True)
    for round_ in range(args.rounds):
        order = modes[round_ % len(modes):] + modes[:round_ % len(modes)]
        for mode in order:
            before = compare.process_table()
            row = {'mode': mode, 'round': round_ + 1, 'samples': []}
            with environment({'BRUSTER_DEEP_RAW': '1' if mode == 'raw' else None, 'BRUSTER_DEEP_TRACE': '1' if mode in ('raw', 'instrumented') else None}):
                if mode == 'agent-browser':
                    client = compare.AgentClient(args.deps / 'node_modules/agent-browser/bin/agent-browser-linux-x64', args.chrome, f'deep-{round_}')
                elif mode in ('playwright', 'playwright-shell', 'puppeteer'):
                    client = compare.ProcessClient([str(args.node), str(Path(__file__).with_name('bench_competitor_driver.mjs')), mode, str(args.shell if mode == 'playwright-shell' else args.chrome), str(args.deps)], True)
                elif mode == 'mcp':
                    client = MCPClient(args.baseline)
                else:
                    client = compare.ProcessClient([str(args.prototype if mode in ('raw', 'instrumented') else args.baseline), '--hidden'], False)
            try:
                client.navigate(f'{base}/large')
                _, live, _ = client.call('eval', {'expression': compare.EXTRACT})
                if isinstance(live, str):
                    live = json.loads(live)
                compare.validate_extract(live, 2000, 'large')
                signature = hashlib.sha256(json.dumps(live, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
                row['extract_sha256'] = signature
                expressions = {
                    'live-object': compare.EXTRACT,
                    'live-json': f'JSON.stringify({compare.EXTRACT})',
                    'cached-object': 'window.__deepObject',
                    'cached-json': 'window.__deepString',
                    'big-object': 'window.__deepBig',
                    'big-json': 'window.__deepBigString',
                    'tiny': '42',
                }
                client.call('eval', {'expression': f'(() => {{window.__deepObject={compare.EXTRACT};window.__deepString=JSON.stringify(__deepObject);window.__deepBig=Array(10).fill(__deepObject);window.__deepBigString=JSON.stringify(__deepBig);return true;}})()'})
                for name, expression in expressions.items():
                    samples = []
                    for i in range(args.iterations + 3):
                        elapsed, result, size = client.call('eval', {'expression': expression})
                        if isinstance(result, str):
                            result = json.loads(result)
                        expected = 42 if name == 'tiny' else [live] * 10 if name.startswith('big-') else live
                        assert result == expected, (mode, name)
                        if i >= 3:
                            samples.append({'ms': elapsed, 'wire_bytes': size})
                    if mode == 'baseline' and round_ == 0:
                        content = json.dumps(expected, separators=(',', ':')) if name.endswith('json') else expected
                        (payload_dir / f'{name}.json').write_text(json.dumps({'id': 1, 'result': content}, separators=(',', ':')))
                    row['samples'].append({'payload': name, 'values': samples})
                # Batch timing compensates for the engine's coarse clock.
                profile = f'''(() => {{
                    const n=100, now=()=>performance.now(); let t=now(), v;
                    for(let i=0;i<n;i++) v={compare.EXTRACT};
                    const dom=(now()-t)/n; t=now();
                    for(let i=0;i<n;i++) v=JSON.stringify(__deepObject);
                    const object=(now()-t)/n; t=now();
                    for(let i=0;i<n;i++) v=JSON.stringify({{id:1,result:__deepString}});
                    return {{dom_ms:dom,object_stringify_ms:object,string_envelope_ms:(now()-t)/n,chars:__deepString.length,check:v.length}};
                }})()'''
                _, component, _ = client.call('eval', {'expression': profile})
                row['components'] = json.loads(component) if isinstance(component, str) else component
                row['memory'] = compare.memory_forest(before, mode in ('baseline', 'raw', 'instrumented', 'mcp'))
                assert row['memory']['complete'], row['memory']
            finally:
                owned = compare.owned_processes(before)
                client.close()
                row['stderr'] = client.stderr
                row['forced_cleanup'] = compare.cleanup(owned)
            rows.append(row)
            save(args, rows, server)
            print(mode, round_ + 1, {s['payload']: round(statistics.median(v['ms'] for v in s['values']), 3) for s in row['samples']}, row.get('components'), flush=True)
    return rows


def correctness(args, server):
    rows = []
    base = f'http://127.0.0.1:{server.server_port}'
    for mode in (args.modes or 'baseline').split(','):
        before = compare.process_table()
        client = compare.ProcessClient([str(args.prototype if mode == 'prototype' else args.baseline), '--hidden'], False)
        try:
            client.navigate(f'{base}/tiny')
            for round_ in range(args.rounds):
                first, second = client.next_id + 1, client.next_id + 2
                client.next_id = second
                url = f'{base}/delayed?round={round_}'
                for id_ in (first, second):
                    client.proc.stdin.write(json.dumps({'id': id_, 'method': 'navigate', 'params': {'url': url, 'timeout': 2000}}).encode() + b'\n')
                    client.proc.stdin.flush()
                    if id_ == first:
                        time.sleep(0.03)
                replies = [client.wait(lambda o: o.get('id') in (first, second))[1] for _ in range(2)]
                row = {'mode': mode, 'round': round_ + 1, 'first_id': first, 'second_id': second, 'replies': replies}
                rows.append(row)
                client.navigate(f'{base}/tiny?recover={round_}')
                save(args, rows, server)
                print(row, flush=True)
        finally:
            owned = compare.owned_processes(before)
            client.close()
            rows.append({'mode': mode, 'stderr': client.stderr, 'forced_cleanup': compare.cleanup(owned)})
            save(args, rows, server)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('workload', choices=['navigation', 'graphics', 'timers', 'extraction', 'correctness'])
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--prototype', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--rounds', type=int, default=3)
    parser.add_argument('--modes')
    parser.add_argument('--iterations', type=int, default=15)
    parser.add_argument('--deps', type=Path)
    parser.add_argument('--chrome', type=Path)
    parser.add_argument('--shell', type=Path)
    parser.add_argument('--node', type=Path)
    args = parser.parse_args()
    if args.rounds < 1 or args.iterations < 1:
        parser.error('rounds and iterations must be positive')
    if args.workload == 'extraction':
        modes = (args.modes or 'baseline,raw,mcp,playwright-shell,playwright,puppeteer,agent-browser').split(',')
        if set(modes) & {'playwright-shell', 'playwright', 'puppeteer', 'agent-browser'}:
            if any(getattr(args, key) is None for key in ('deps', 'chrome', 'shell', 'node')):
                parser.error('competitor extraction requires --deps, --chrome, --shell, and --node')
    for key in ('deps', 'chrome', 'shell', 'node'):
        if getattr(args, key) is not None:
            setattr(args, key, getattr(args, key).resolve(strict=True))
    args.baseline = args.baseline.resolve(strict=True)
    args.prototype = args.prototype.resolve(strict=True)
    args.output = args.output.resolve()
    if ctypes.CDLL(None).prctl(36, 1, 0, 0, 0) != 0:
        raise RuntimeError('cannot enable subreaper accounting')
    server = audit.ThreadingHTTPServer(('127.0.0.1', 0), Fixtures)
    server.arrivals, server.image_hits, server.hits_lock = [], 0, threading.Lock()
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        globals()[args.workload](args, server)
    finally:
        server.shutdown()
        server.server_close()


if __name__ == '__main__':
    main()
