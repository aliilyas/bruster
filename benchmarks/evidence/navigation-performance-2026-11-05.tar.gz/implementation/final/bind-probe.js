const bind = __bruster.bind;
window.skippedBind = false;
__bruster.bind = generation => {
    if (window.skippedBind) return bind(generation);
    window.skippedBind = true;
    window.ipc.postMessage(JSON.stringify({ bound: true, generation: 0, document: __bruster.document }));
};
