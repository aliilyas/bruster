| Paired metric | Baseline | Candidate | Change |
|---|---:|---:|---:|
| launch_to_page_ms | 890.77 [872.82–918.90] | 302.27 [293.91–341.60] | -66.1% |
| ready_ms | 265.48 [254.13–291.30] | 176.35 [165.08–194.30] | -33.6% |
| first_navigation_ms | 622.80 [613.71–633.69] | 129.89 [120.76–155.64] | -79.1% |
| warm_navigation_ms | 12.08 [8.53–17.06] | 12.41 [7.96–18.97] | +2.7% |
| graphics_pss_mib | 278.52 [277.49–279.92] | 239.72 [238.82–243.19] | -13.9% |
| graphics_screenshot_ms | 42.89 [40.14–43.73] | 32.64 [30.89–41.55] | -23.9% |
| live_object_ms | 7.96 [6.06–11.26] | 5.49 [4.60–7.76] | -31.0% |
| live_string_ms | 6.60 [5.49–8.76] | 5.79 [4.82–9.72] | -12.4% |
| cached_object_ms | 2.97 [2.49–4.12] | 1.65 [1.27–6.81] | -44.3% |
| cached_string_ms | 2.90 [2.42–4.65] | 2.31 [1.70–4.83] | -20.4% |
| stress_object_ms | 28.30 [25.20–37.66] | 11.93 [10.28–14.31] | -57.9% |

| Configuration | Launch → page (ms) | Warm tiny navigation (ms) | Large extraction (ms) | PSS + display (MiB) | Installed runtime (MB) |
|---|---:|---:|---:|---:|---:|
| bruster | 284.55 [220.95–359.59] | 6.20 [4.66–12.58] | 16.92 [4.95–21.87] | 215.51 [213.64–216.03] | 442.47 |
| playwright | 1114.83 [1084.13–1496.27] | 16.93 [12.92–24.76] | 111.76 [81.37–178.89] | 473.54 [457.65–475.49] | 655.81 |
| puppeteer | 1494.02 [1378.86–1595.92] | 15.68 [12.89–20.63] | 27.12 [17.86–49.35] | 407.99 [405.80–410.97] | 672.88 |
| agent-browser | 4075.86 [3963.61–4122.02] | 23.12 [18.18–32.47] | 30.96 [24.40–39.65] | 483.54 [482.48–484.81] | 535.33 |
| playwright-shell | 992.77 [860.86–1102.00] | 11.55 [8.49–16.35] | 105.42 [77.86–167.57] | 320.47 [318.67–323.27] | 455.50 |

Timers:
{
  "baseline": [
    {
      "completed": 0,
      "threads": 24,
      "parent_virtual_mib": 72679.31640625,
      "parent_rss_mib": 184.34765625,
      "total_pss_mib": 265.6494140625,
      "elapsed_s": 4.067999952894752e-06
    },
    {
      "completed": 50,
      "threads": 74,
      "parent_virtual_mib": 73548.1015625,
      "parent_rss_mib": 185.33203125,
      "total_pss_mib": 276.4150390625,
      "elapsed_s": 0.6441097260001243
    },
    {
      "completed": 100,
      "threads": 124,
      "parent_virtual_mib": 73648.921875,
      "parent_rss_mib": 186.109375,
      "total_pss_mib": 277.6416015625,
      "elapsed_s": 1.3051947149999705
    },
    {
      "completed": 150,
      "threads": 174,
      "parent_virtual_mib": 73749.703125,
      "parent_rss_mib": 186.75,
      "total_pss_mib": 278.2158203125,
      "elapsed_s": 2.0017836639999587
    },
    {
      "completed": 200,
      "threads": 224,
      "parent_virtual_mib": 73850.484375,
      "parent_rss_mib": 187.41015625,
      "total_pss_mib": 279.416015625,
      "elapsed_s": 2.707654285999979
    }
  ],
  "candidate": [
    {
      "completed": 0,
      "threads": 18,
      "parent_virtual_mib": 72118.52734375,
      "parent_rss_mib": 151.4921875,
      "total_pss_mib": 227.2607421875,
      "elapsed_s": 2.3640000108571257e-06
    },
    {
      "completed": 50,
      "threads": 18,
      "parent_virtual_mib": 72118.52734375,
      "parent_rss_mib": 151.87109375,
      "total_pss_mib": 236.4130859375,
      "elapsed_s": 0.6299782159999268
    },
    {
      "completed": 100,
      "threads": 18,
      "parent_virtual_mib": 72118.56640625,
      "parent_rss_mib": 152.02734375,
      "total_pss_mib": 235.4677734375,
      "elapsed_s": 1.2443112810001367
    },
    {
      "completed": 150,
      "threads": 18,
      "parent_virtual_mib": 72118.56640625,
      "parent_rss_mib": 152.0859375,
      "total_pss_mib": 236.0380859375,
      "elapsed_s": 1.8948966049999854
    },
    {
      "completed": 200,
      "threads": 18,
      "parent_virtual_mib": 72118.56640625,
      "parent_rss_mib": 152.22265625,
      "total_pss_mib": 239.7763671875,
      "elapsed_s": 2.5570043469999746
    }
  ]
}
