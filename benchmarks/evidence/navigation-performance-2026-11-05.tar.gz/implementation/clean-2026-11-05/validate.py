import datetime
import hashlib
import json
from pathlib import Path
import bench_report

root = Path(__file__).resolve().parent
checks = {}
for workload, rounds in [('startup', 20), ('graphics', 3), ('transport', 3), ('timers', 1)]:
    data = json.loads((root / f'paired-{workload}.json').read_text())
    rows = data['samples']
    assert len(rows) == 2 * rounds
    assert {(r['build'], r['round']) for r in rows} == {(b, r) for b in ('baseline', 'candidate') for r in range(1, rounds + 1)}
    for row in rows:
        assert not any(row.get(k) for k in ('error', 'close_error', 'forced_cleanup', 'competing_before', 'competing_after')), row
        assert row['started_utc'] < row['finished_utc']
        for memory in row.get('memory', []) + [s['memory'] for s in row.get('timers', [])]:
            assert memory['complete']
            assert abs(sum(p['pss_kib'] for p in memory['processes'] + memory['display']) / 1024 - memory['total_pss_mib']) < 1e-9
        if workload == 'graphics':
            path = (root / f'paired-graphics.json').with_suffix(f".{row['build']}-{row['round']}.png")
            assert hashlib.sha256(path.read_bytes()).hexdigest() == row['png_sha256']
    checks[f'paired-{workload}'] = len(rows)
for version in ('candidate', 'baseline'):
    data = json.loads((root / f'compare-{version}/summary.json').read_text())
    rows = json.loads((root / f'compare-{version}/samples.json').read_text())
    footprint = json.loads((root / f'footprint-{version}.json').read_text())
    bench_report.validate(data['metadata'], rows, footprint)
    assert hashlib.sha256((root / 'package-lock.json').read_bytes()).hexdigest() == data['metadata']['package_lock_sha256']
    assert all(not row[key] for row in rows for key in ('competing_before', 'competing_at_memory', 'competing_after', 'cleanup_forced_processes'))
    assert all(not any(f['name'] in ('graceful_close', 'process_cleanup') for f in row['failures']) for row in rows)
    checks[f'compare-{version}'] = {'sessions': len(rows), 'fault_probe_failures': [dict(tool=r['tool'], round=r['round'], **f) for r in rows for f in r['failures']]}
record = {'validated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'checks': checks}
record['desktop_controllers_after'] = []
for item in json.loads((root / 'scheduling.json').read_text())['checks'][-1]['desktop_controllers']:
    path = Path('/proc') / str(item['pid'])
    if path.exists():
        fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
        assert fields[19] == item['stat'].rsplit(')', 1)[1].split()[19], 'Desktop process identity changed'
        record['desktop_controllers_after'].append({'pid': item['pid'], 'stat': (path / 'stat').read_text(),
                                                   'status': (path / 'status').read_text()})
(root / 'validation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
