"""Generate reproducible tables from validated samples, retaining every row."""
import json
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent
assert (root / 'validation.json').exists(), 'Validate before summarizing'
summary = {}

def stats(values):
    return {'n': len(values), 'median': statistics.median(values), 'min': min(values), 'max': max(values)}

def add(key, rows, values):
    summary[key] = {build: stats(values([r for r in rows if r['build'] == build])) for build in ('baseline', 'candidate')}
    a, b = (summary[key][build]['median'] for build in ('baseline', 'candidate'))
    summary[key]['change_percent'] = (b / a - 1) * 100

rows = json.loads((root / 'paired-startup.json').read_text())['samples']
add('launch_to_page_ms', rows, lambda rs: [r['launch_to_page_ms'] for r in rs])
add('ready_ms', rows, lambda rs: [r['ready_ms'] for r in rs])
add('first_navigation_ms', rows, lambda rs: [r['navigate_ms'] for r in rs])
add('warm_navigation_ms', rows, lambda rs: [v for r in rs for v in r['warm_navigation_ms']])
rows = json.loads((root / 'paired-graphics.json').read_text())['samples']
add('graphics_pss_mib', rows, lambda rs: [statistics.median(s['total_pss_mib'] for s in r['memory']) for r in rs])
add('graphics_screenshot_ms', rows, lambda rs: [r['screenshot_ms'] for r in rs])
rows = json.loads((root / 'paired-transport.json').read_text())['samples']
for key in ('live_object', 'live_string', 'cached_object', 'cached_string', 'stress_object'):
    add(key + '_ms', rows, lambda rs: [s['ms'] for r in rs for s in r['transport'][key]])
    summary[key + '_ms']['wire_bytes'] = {build: stats([s['wire_bytes'] for r in rows if r['build'] == build for s in r['transport'][key]]) for build in ('baseline', 'candidate')}
rows = json.loads((root / 'paired-timers.json').read_text())['samples']
summary['timers'] = {r['build']: [{'completed': s['completed'], 'threads': s['parent']['Threads'],
                                 'parent_virtual_mib': s['parent']['VmSize'] / 1024,
                                 'parent_rss_mib': s['parent']['VmRSS'] / 1024,
                                 'total_pss_mib': s['memory']['total_pss_mib'],
                                 'elapsed_s': s['elapsed_s']} for s in r['timers']] for r in rows}
candidate = json.loads((root / 'compare-candidate/summary.json').read_text())
baseline = json.loads((root / 'compare-baseline/summary.json').read_text())
summary['competitors'] = candidate
summary['baseline_comparison'] = baseline['summary']['bruster']
summary['footprint'] = {version: json.loads((root / f'footprint-{version}.json').read_text())['tool_totals'] for version in ('baseline', 'candidate')}
(root / 'report-summary.json').write_text(json.dumps(summary, indent=2) + '\n')

def cell(s):
    return f"{s['median']:.2f} [{s['min']:.2f}–{s['max']:.2f}]"

lines = ['| Paired metric | Baseline | Candidate | Change |', '|---|---:|---:|---:|']
for key, item in summary.items():
    if 'change_percent' in item:
        lines.append(f"| {key} | {cell(item['baseline'])} | {cell(item['candidate'])} | {item['change_percent']:+.1f}% |")
lines.extend(['', '| Configuration | Launch → page (ms) | Warm tiny navigation (ms) | Large extraction (ms) | PSS + display (MiB) | Installed runtime (MB) |', '|---|---:|---:|---:|---:|---:|'])
for tool, item in candidate['summary'].items():
    values = [cell(item[key]) for key in ('launch_to_first_page_ms', 'tiny_navigation_ms', 'large_extract_ms', 'total_pss_mib')]
    values.append(f"{summary['footprint']['candidate'][tool]['bytes'] / 1e6:.2f}")
    lines.append('| ' + ' | '.join([tool, *values]) + ' |')
lines.extend(['', 'Timers:', json.dumps(summary['timers'], indent=2)])
text = '\n'.join(lines) + '\n'
(root / 'report-tables.md').write_text(text)
print(text)
