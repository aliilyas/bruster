"""Install current stable CfT archives using the official download manifest."""
import datetime
import hashlib
import json
import shutil
import subprocess
import urllib.request
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent
url = 'https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json'
manifest = json.loads((root.parent / 'clean-2026-11-05/chrome-stable-resolution.json').read_text())
(root / 'chrome-download-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
stable = manifest['channels']['Stable']
record = {'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'selection': 'Current Chrome for Testing stable from the official manifest, with matching Headless Shell',
          'manifest_url': url, 'buildId': stable['version'], 'platform': 'linux64', 'browsers': {}, 'downloads': {}}
target = root / 'browsers' / stable['version']
target.mkdir(parents=True, exist_ok=True)
for name in ('chrome', 'chrome-headless-shell'):
    source = next(item['url'] for item in stable['downloads'][name] if item['platform'] == 'linux64')
    archive = target / f'{name}.zip'
    print('Downloading', source, flush=True)
    subprocess.run(['curl', '-4', '--fail', '--location', '--connect-timeout', '15',
                    '--max-time', '180', '--retry', '2', '--output', str(archive), source], check=True)
    record['downloads'][name] = {'url': source, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size}
    with zipfile.ZipFile(archive) as zipped:
        for info in zipped.infolist():
            path = (target / info.filename).resolve()
            assert path.is_relative_to(target.resolve()), info.filename
            zipped.extract(info, target)
            mode = info.external_attr >> 16
            if mode:
                path.chmod(mode & 0o777)
    binary = target / f'{name}-linux64' / name
    assert binary.is_file(), binary
    record['browsers'][name] = str(binary)
(root / 'browser-versions.json').write_text(json.dumps(record, indent=2) + '\n')
(root / 'browser-paths.env').write_text(f"export BENCH_CHROME='{record['browsers']['chrome']}'\nexport BENCH_SHELL='{record['browsers']['chrome-headless-shell']}'\n")
print(json.dumps(record, indent=2), flush=True)
