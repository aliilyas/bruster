import { Browser, BrowserPlatform, ChromeReleaseChannel, resolveBuildId, install } from '@puppeteer/browsers';
import { writeFile } from 'node:fs/promises';
import path from 'node:path';

const platform = BrowserPlatform.LINUX;
const buildId = await resolveBuildId(Browser.CHROME, platform, ChromeReleaseChannel.STABLE);
const record = {
  checked_utc: new Date().toISOString(),
  selection: 'Current Chrome for Testing stable, shared by all full-Chrome clients; matching Headless Shell',
  buildId,
  platform,
  browsers: {},
};
for (const browser of [Browser.CHROME, Browser.CHROMEHEADLESSSHELL]) {
  const installed = await install({ browser, buildId, platform, cacheDir: path.resolve('browsers') });
  record.browsers[browser] = installed.executablePath;
}
await writeFile('browser-versions.json', JSON.stringify(record, null, 2) + '\n');
await writeFile('browser-paths.env',
  `export BENCH_CHROME='${record.browsers[Browser.CHROME]}'\n` +
  `export BENCH_SHELL='${record.browsers[Browser.CHROMEHEADLESSSHELL]}'\n`);
console.log(JSON.stringify(record, null, 2));
