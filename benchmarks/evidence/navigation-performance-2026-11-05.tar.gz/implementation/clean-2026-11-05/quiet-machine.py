"""Record the completed primary campaign and require two quiet minutes."""
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'harness-main/scripts'))
from bench_compare import background_work

campaign = Path('/home/admin/Projects/.bruster-build/website-compatibility-1000/benchmarks/results/websites-1000')
progress = json.loads((campaign / 'campaign-progress.json').read_text())
assert progress['completed_domains'] == progress['required_domains'] == 1000, progress
completion_path = campaign / 'campaign-completion.json'
record = {
    'started_utc': datetime.now(timezone.utc).isoformat(),
    'external_progress': progress,
    'external_completion': json.loads(completion_path.read_text()) if completion_path.exists() else None,
    'basis': 'Primary campaign reached 1000/1000. Final completion marker absent at resumption; process inactivity and a two-minute quiet gate authorize scheduling, not a claim that every external campaign stage passed.',
    'required_quiet_seconds': 120,
    'checks': [],
}
quiet_since = None
print('Checking for two quiet minutes after completed primary campaign.', flush=True)
while True:
    competing = background_work()
    now = time.monotonic()
    quiet_since = None if competing else (quiet_since if quiet_since is not None else now)
    desktop = []
    approved = json.loads(Path(__file__).with_name('desktop-controller.json').read_text())['processes']
    for path in Path('/proc').glob('[0-9]*/comm'):
        try:
            if path.parent.name in approved:
                desktop.append({'pid': int(path.parent.name), 'stat': (path.parent / 'stat').read_text(),
                                'exe': str((path.parent / 'exe').resolve()),
                                'cmdline': (path.parent / 'cmdline').read_bytes().decode().split('\0')})
        except OSError:
            pass
    record['checks'].append({'checked_utc': datetime.now(timezone.utc).isoformat(),
                             'competing_processes': competing, 'desktop_controllers': desktop})
    record['quiet_seconds'] = now - quiet_since if quiet_since is not None else 0
    (root / 'scheduling.json').write_text(json.dumps(record, indent=2) + '\n')
    if record['quiet_seconds'] >= record['required_quiet_seconds']:
        print('Two quiet minutes observed.', flush=True)
        break
    time.sleep(10)
