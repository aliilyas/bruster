"""Deployment contracts: subpath links, indexing, and immutable benchmark evidence."""
import contextlib
import io
import json
import re
import struct
import tempfile
import tomllib
import unittest
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urljoin, urlsplit
from xml.etree import ElementTree as ET

import bench_report
import site_build
from lab.build import assemble
from site_layout import REPOSITORY, ROOT, SITE
from test_bench_publish import fixture


class Document(HTMLParser):
    def __init__(self, content):
        super().__init__(convert_charrefs=True)
        self.ids = []
        self.links = []
        self.references = []
        self.meta = {}
        self.canonical = []
        self.titles = []
        self.headings = 0
        self.schemas = []
        self.capture = None
        self.buffer = []
        self.feed(content)

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        if 'id' in attrs:
            self.ids.append(attrs['id'])
        for name in ('href', 'src'):
            if attrs.get(name):
                self.links.append(attrs[name])
        for name in ('aria-controls', 'aria-labelledby', 'data-copy'):
            self.references.extend(attrs.get(name, '').split())
        if tag == 'meta':
            self.meta[attrs.get('name', attrs.get('property'))] = attrs.get('content')
        if tag == 'link' and attrs.get('rel') == 'canonical':
            self.canonical.append(attrs['href'])
        if tag == 'h1':
            self.headings += 1
        if tag == 'title' or (tag == 'script' and attrs.get('type') == 'application/ld+json'):
            self.capture = tag
            self.buffer = []

    def handle_data(self, data):
        if self.capture:
            self.buffer.append(data)

    def handle_endtag(self, tag):
        if tag == self.capture:
            value = ''.join(self.buffer)
            if tag == 'title':
                self.titles.append(value)
            else:
                self.schemas.append(json.loads(value))
            self.capture = None


class SiteBuild(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.measurements = self.root / 'published'
        for run in (2, 1):  # Publish out of order, like concurrent benchmark jobs.
            results = self.root / f'results-{run}'
            fixture(results, run=run)
            bench_report.install(results, self.measurements)

    def build(self, output, base_url, measurements=None):
        with contextlib.redirect_stdout(io.StringIO()):
            return site_build.build(output, measurements, base_url)

    def assert_site_links(self, output, base_url):
        verifications = {path.name: path.read_bytes() for path in SITE.glob('google*.html')}
        for name, content in verifications.items():
            self.assertEqual((output / name).read_bytes(), content, 'Verification file was altered')
        documents = {path.relative_to(output).as_posix(): Document(path.read_text())
                     for path in output.rglob('*.html') if path.relative_to(output).as_posix() not in verifications}
        origin = urlsplit(base_url)

        def assert_link(name, link, page_url):
            target = urlsplit(urljoin(page_url, link))
            if (target.scheme, target.netloc) != (origin.scheme, origin.netloc):
                return
            self.assertTrue(target.path.startswith(origin.path), f'Escaped project path: {link}')
            target_name = unquote(target.path[len(origin.path):])
            target_file = output / target_name
            if target_file.is_dir():
                target_file /= 'index.html'
            self.assertTrue(target_file.is_file(), f'{name}: missing {link}')
            if target.fragment and target_file.suffix == '.html':
                resolved = target_file.relative_to(output).as_posix()
                self.assertIn(unquote(target.fragment), documents[resolved].ids, f'{name}: missing anchor {link}')

        titles = []
        for name, document in documents.items():
            with self.subTest(page=name):
                self.assertEqual(document.headings, 1)
                self.assertEqual(len(document.ids), len(set(document.ids)), 'Duplicate IDs')
                self.assertTrue(set(document.references) <= set(document.ids), 'Missing interactive target')
                self.assertEqual(len(document.titles), 1)
                titles.extend(document.titles)
                path = name.removesuffix('index.html')
                self.assertEqual(document.canonical, [base_url + path])
                self.assertEqual(document.meta['og:url'], base_url + path)
                self.assertEqual(document.meta['og:image'], base_url + 'assets/social.png')
                self.assertTrue(document.meta['description'])
                self.assertTrue(document.schemas)
                webpage = next(node for node in document.schemas[0]['@graph'] if node['@type']=='WebPage')
                self.assertEqual(webpage['url'],base_url + path)
                self.assertEqual(webpage['isPartOf'],{'@id':base_url + '#website'})
                self.assertEqual(webpage['about'], {'@id': base_url + '#software'})
                self.assertNotIn('{{', (output / name).read_text())
                for link in document.links:
                    assert_link(name, link, base_url + path)
        self.assertEqual(len(titles), len(set(titles)), 'Every page should have its own search title')
        for name in ('llms.txt', 'llms-full.txt', 'docs/reference.md'):
            with self.subTest(resource=name):
                content = (output / name).read_text()
                self.assertNotIn('{{', content)
                links = re.findall(r'\]\(([^\s)]+)\)', content)
                self.assertTrue(links)
                for link in links:
                    self.assertIn(urlsplit(link).scheme, ('http', 'https'), f'{name}: non-absolute link {link}')
                    assert_link(name, link, base_url + name)
        home_graph = {node['@id']: node for node in documents['index.html'].schemas[0]['@graph']}
        software = home_graph[base_url + '#software']
        version = tomllib.loads((ROOT / 'Cargo.toml').read_text())['package']['version']
        self.assertEqual(software['softwareVersion'], version)
        self.assertEqual(software['mainEntityOfPage'], {'@id': base_url + '#webpage'})
        self.assertEqual(software['softwareHelp'], {'@id': base_url + 'docs/#webpage'})
        source = home_graph[software['subjectOf']['@id']]
        self.assertEqual(source['codeRepository'], REPOSITORY)
        self.assertEqual(source['targetProduct'], {'@id': software['@id']})
        self.assertIn(version, (output / 'llms.txt').read_text())
        reference = (output / 'docs/reference.md').read_text()
        # Export the maintained method table verbatim, including escaped pipes and code.
        source_api = (ROOT / 'docs/reference.md').read_text().split('\n## API\n')[1].split('\n## Events\n')[0]
        self.assertIn(source_api, reference)
        self.assertIn(REPOSITORY + '/blob/main/server.json', reference)
        self.assertTrue((output / 'llms-full.txt').read_text().endswith(reference))
        return documents

    def test_project_and_custom_domain_builds_keep_all_links_and_evidence(self):
        (self.measurements / 'CNAME').write_text('docs.example.test')
        before = {p.relative_to(self.measurements): p.read_bytes()
                  for p in self.measurements.rglob('*') if p.is_file()}
        (self.measurements / 'private-source.txt').write_text('not a public asset')
        for index, base_url in enumerate(('https://example.test/bruster/', 'https://docs.example.test/')):
            output = self.root / f'site-{index}'
            history = self.build(output, base_url, self.measurements)
            documents = self.assert_site_links(output, base_url)
            self.assertEqual([r['context']['run_number'] for r in history], [2, 1])
            self.assertFalse((output / 'private-source.txt').exists())
            self.assertEqual((output / 'CNAME').read_text(), 'docs.example.test')
            for name, content in before.items():
                self.assertEqual((self.measurements / name).read_bytes(), content, 'Input checkout was modified')
                if name.suffix in ('.json', '.md'):
                    self.assertEqual((output / name).read_bytes(), content, 'Published evidence was altered')
            sitemap = ET.parse(output / 'sitemap.xml')
            locations = [item.text for item in sitemap.findall('.//{*}loc')]
            self.assertEqual(set(locations), {base_url + path for path in ('', 'docs/', 'testing/', 'mcp/', 'compare/', 'benchmarks/')})
            for name, document in documents.items():
                archived = '/runs/' in name or name == '404.html'
                self.assertEqual('noindex' in document.meta['robots'], archived)
            self.assertEqual((output / 'robots.txt').exists(), index == 1)
            if index == 1:
                self.assertIn(base_url + 'sitemap.xml', (output / 'robots.txt').read_text())
            self.assertEqual(struct.unpack('>II', (output / 'assets/social.png').read_bytes()[16:24]), (1200, 630))
            self.assertEqual((output / 'assets/logo.svg').read_bytes(), (ROOT / 'assets/logo.svg').read_bytes())
            self.assertIn('selector|ref', (output / 'docs/index.html').read_text())

    def test_empty_preview_has_working_navigation_and_no_fake_measurements(self):
        output = self.root / 'empty'
        history = self.build(output, 'https://example.test/bruster/')
        self.assertEqual(history, [])
        documents = self.assert_site_links(output, 'https://example.test/bruster/')
        self.assertIn('noindex', documents['benchmarks/index.html'].meta['robots'])
        self.assertIn('after the first successful benchmark run', (output / 'index.html').read_text())
        self.assertNotIn('https://example.test/bruster/benchmarks/', (output / 'sitemap.xml').read_text())

    def test_test_lab_assembly_preserves_product_pages_and_benchmark_evidence(self):
        for index, base_url in enumerate(('https://example.test/bruster/', 'https://docs.example.test/')):
            with self.subTest(base_url=base_url):
                output, published = self.root / f'product-{index}', self.root / f'combined-{index}'
                self.build(output, base_url, self.measurements)
                manifest = assemble(output, published, base_url=base_url)
                self.assertGreaterEqual(len(manifest['cases']), 300)
                home = (published / 'index.html').read_text()
                self.assertEqual(home.count('data-bruster-test-lab'), 1)
                self.assertIn('Browser automation.<br>', home)
                self.assertEqual(Document(home).canonical, [base_url])
                for name in ('docs/index.html', 'testing/index.html', 'benchmarks/latest.json', 'benchmarks/history.json',
                             'llms.txt', 'llms-full.txt', 'docs/reference.md',
                             *(path.name for path in SITE.glob('google*.html'))):
                    self.assertEqual((published / name).read_bytes(), (output / name).read_bytes())
                original = [item.text for item in ET.parse(output / 'sitemap.xml').findall('.//{*}loc')]
                locations = [item.text for item in ET.parse(published / 'sitemap.xml').findall('.//{*}loc')]
                self.assertEqual(locations, original + [base_url + 'test-lab/'])
                lab = published / 'test-lab'
                catalog = Document((lab / 'index.html').read_text())
                self.assertEqual(catalog.canonical, [base_url + 'test-lab/'])
                self.assertEqual(catalog.meta['og:url'], base_url + 'test-lab/')
                self.assertEqual(catalog.meta['og:image'], base_url + 'assets/social.png')
                self.assertEqual(catalog.headings, 1)
                collection = next(node for node in catalog.schemas[0]['@graph'] if node['@type']=='CollectionPage')
                self.assertEqual(collection['url'], catalog.canonical[0])
                self.assertEqual(collection['about'], {'@id': base_url + '#software'})
                # Every case is discoverable in the initial HTML, without fetching JS or the manifest.
                for case in manifest['cases']:
                    self.assertIn(case['url'], catalog.links)
                    self.assertTrue((lab / case['url']).is_file())
                for file in lab.rglob('*.html'):
                    document = Document(file.read_text())
                    self.assertEqual('noindex' in document.meta['robots'], file != lab / 'index.html', str(file))

    def test_rejects_output_over_source_and_missing_measurement_input(self):
        for path in (ROOT, SITE, SITE / 'generated'):
            with self.subTest(path=path), self.assertRaises(ValueError):
                self.build(path, 'https://example.test/')
        with self.assertRaisesRegex(ValueError, 'must be separate'):
            self.build(self.measurements, 'https://example.test/', self.measurements)
        with self.assertRaisesRegex(ValueError, 'Missing published benchmarks'):
            self.build(self.root / 'missing', 'https://example.test/', self.root / 'does-not-exist')


if __name__ == '__main__':
    unittest.main()
