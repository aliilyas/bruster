# Retained measurement batches

- `paired-*.json`, `compare-{baseline,candidate}/`: first batch,
  2026-10-28 00:35–00:41 UTC, candidate `5873f49`. No competing work was
  recorded. This predates the separate website campaign's 00:51 UTC preflight.
  Historical confirmation of the implementation, not the final-revision result.
- `final/paired-startup.json`: excluded. The raw rows record competing Bruster
  PID 292818 in rounds 5–9 (nine baseline/candidate samples in total).
  An earlier progress update incorrectly described all paired probes as clean.
- `final/paired-{graphics,transport,timers}.json`: retained, but excluded from
  final claims along with the rest of this batch. These used the earlier,
  narrower concurrency detector while another benchmark was underway.
- `final/compare-{baseline,candidate}/`: excluded. The comparison overlapped
  the website benchmark's primary phase (started 01:04:41.950901 UTC).
  Candidate and baseline comparisons ended at 01:06:49.804825 and
  01:07:21.945593 UTC respectively.
- `final/footprint-*.json`: retained installed-file inventories associated with
  that batch; regenerate with the clean process samples for final reporting.
- `clean/`: cancelled October preparation for `d4c56d9`. The server restart
  stopped its marker-based wait before any browser measurements ran. Its frozen
  harness, manifests, provenance and waiting log remain preserved.
- `clean-2026-11-05/`: fresh final-candidate measurement directory. The external
  primary campaign records 1,000/1,000 domains as of October 28; its final
  completion marker is absent. A read-only process check and two quiet minutes
  replace the obsolete marker requirement. `scheduling.json` records every
  check. Current-main harness sources include the ownership-snapshot race fix;
  exact source and file hashes are recorded independently of the runtime builds.
  Its four paired workloads completed cleanly. The first competitor comparison
  recorded Cargo PID 35883 during its final session; all 25 sessions are retained
  but excluded in `clean-2026-11-05/compare-candidate-overlap/`. The following
  baseline comparison rejected its first launch and is retained in
  `compare-baseline-overlap/`. Only the affected comparisons are rerun after a
  fresh quiet gate; `comparison-retry.json` and both scheduling records retain
  this boundary.
  The second comparison completed ten sessions before external WebKit processes
  39345/39350 appeared; the remaining launch was rejected. All ten are retained
  but excluded in `compare-candidate-overlap-2/`. The November 6 restart left
  Firefox active; the remaining comparisons await a quiet window. Completed
  paired workloads are not repeated. The final comparison ran November 6,
  00:39:30–00:42:07 UTC with Playwright 1.65.0, Puppeteer 25.16.0,
  agent-browser 0.41.2 and Chrome/Headless Shell 157.0.8103.38, after 175
  scheduling checks and a fresh two-minute quiet interval. All 25 candidate
  comparison sessions plus five subsequent baseline sessions passed accounting,
  concurrency and cleanup validation. Both full-Chrome and Headless-Shell
  Playwright retained five immediate error-page recovery failures each; all
  100 ms retries passed. Final inventories and validation completed at
  00:42:41 UTC. This is the final comparison used in the report.
- `clean-rejected-2026-11-05/`: all 40 proposed startup samples rejected before
  browser launch. The runtime user namespace prevents reading the desktop
  daemon's executable symlink, so the first local idle-daemon filter could not
  verify it. The replacement verifies executable identity on the host and checks
  pinned PID/start time, sleeping state, descendant identity and CPU budget
  inside the sandbox. These rejected rows contribute no timings.
- `clean-pre-node-guard-2026-11-05/`: completed, validated batch superseded by
  the final rerun. Its owned-process records showed Node using `MainThread` as
  its process name, which the concurrency detector did not yet recognize.
  Although no overlap was recorded, the entire batch is excluded from final
  claims; the rerun adds this observed name and a live-process regression.
- `clean-restart-wait-2026-11-05/`: interrupted quiet wait, with 524 recorded
  checks and no browser measurements. Besides real Firefox/build activity, the
  new detector recognized persistent idle OpenCode OpenSERP stdio servers.
  The final local exception pins those helpers' executable, full argv, PID and
  start time; it requires sleeping state, no unapproved descendants and the
  same low-CPU budget as the desktop controller. Normal Node/browser/build
  workloads remain competitors.

The `43b95df` candidate executable's SHA-256 is
`347004630bcecfc6ed762853214c6caf4f4df7debab06869ba669f9bfe87988e`.
The intermediate `85949ef` candidate is `final/candidate-bruster-85949ef`, SHA-256
`cb153bba7b2be04c955743ae17c17f65d19d3de39a5e60a538e9283e2971d27f`.
The final `d4c56d9` candidate is `final/candidate-bruster-d4c56d9`, SHA-256
`0bda5deb9f950ff8390e7bdaa7bb4dda0578fbe19270b1fa220a67568f72ac53`.
The superseded wait preparations are retained in `clean-scheduled-43b95df`
and `clean-scheduled-85949ef`; no browser measurements ran there.
The wait was restarted with the final binary after native platform tests passed.

Fault-probe failures (such as immediate recovery from a refused navigation)
remain recorded even when a later retry succeeds. They are distinct from a
contaminated or incomplete performance measurement.
