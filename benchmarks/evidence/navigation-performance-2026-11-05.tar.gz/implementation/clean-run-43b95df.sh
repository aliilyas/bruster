#!/usr/bin/env bash
set -euo pipefail
source /home/admin/Projects/.bruster-build/env.sh
source /tmp/opencode/bruster-benchmark-validation/deps/browser-paths.env
export CARGO_TARGET_DIR="$PWD/target"
ROOT="$PWD/benchmarks/results/implementation"
OUT="$ROOT/clean"
HARNESS="$OUT/harness"
DEPS=/tmp/opencode/bruster-benchmark-validation/deps
python3 -B "$ROOT/clean-wait.py"
git diff --exit-code 43b95df -- src Cargo.toml Cargo.lock
python3 -B - <<'PY'
import datetime, hashlib, json, pathlib, urllib.request
root = pathlib.Path('benchmarks/results/implementation')
deps = pathlib.Path('/tmp/opencode/bruster-benchmark-validation/deps')
expected = {'baseline-bruster': 'e41dcaf1506d320f55458b053b41d324d5870136b08bd082a8ebadfeea5fb7d5',
            'final/candidate-bruster': '347004630bcecfc6ed762853214c6caf4f4df7debab06869ba669f9bfe87988e'}
for name, sha in expected.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha, name
versions = {'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'packages': {}}
for package, installed in [('playwright', 'playwright-core'), ('playwright-core', 'playwright-core'),
                           ('puppeteer', 'puppeteer-core'), ('puppeteer-core', 'puppeteer-core'),
                           ('agent-browser', 'agent-browser')]:
    with urllib.request.urlopen(f'https://registry.npmjs.org/{package}/latest', timeout=30) as response:
        remote = json.load(response)
    local = json.loads((deps / 'node_modules' / installed / 'package.json').read_text())['version']
    versions['packages'][package] = {'latest': remote['version'], 'installed': local, 'integrity': remote['dist']['integrity']}
versions['playwright_browsers'] = json.loads((deps / 'node_modules/playwright-core/browsers.json').read_text())
(root / 'clean/latest-versions.json').write_text(json.dumps(versions, indent=2) + '\n')
assert all(v['latest'] == v['installed'] for v in versions['packages'].values()), 'Update competitors before measuring'
PY
unset DISPLAY WAYLAND_DISPLAY BRUSTER_TRACE_NAV BRUSTER_TEST_STDERR
for workload in startup graphics transport timers; do
  rounds=3
  if [ "$workload" = startup ]; then rounds=20; fi
  if [ "$workload" = timers ]; then rounds=1; fi
  bwrap --dev-bind / / --overlay-src /usr --overlay-src "$BRUSTER_DEPS/usr" --ro-overlay /usr \
    python3 -B "$HARNESS/bench_performance.py" --baseline "$ROOT/baseline-bruster" \
    --candidate "$ROOT/final/candidate-bruster" --workload "$workload" --rounds "$rounds" \
    --output "$OUT/paired-$workload.json" > "$OUT/paired-$workload.log" 2>&1
done
bwrap --dev-bind / / --overlay-src /usr --overlay-src "$BRUSTER_DEPS/usr" --ro-overlay /usr \
  xvfb-run -a -s '-screen 0 1280x1024x24 -nolisten tcp -extension GLX' \
  python3 -B "$HARNESS/bench_compare.py" --bruster "$ROOT/final/candidate-bruster" \
  --node "$(command -v node)" --chrome "$BENCH_CHROME" --shell "$BENCH_SHELL" --deps "$DEPS" \
  --rounds 5 --iterations 10 --output "$OUT/compare-candidate" > "$OUT/compare-candidate.log" 2>&1
bwrap --dev-bind / / --overlay-src /usr --overlay-src "$BRUSTER_DEPS/usr" --ro-overlay /usr \
  xvfb-run -a python3 -B "$HARNESS/bench_compare.py" --bruster "$ROOT/baseline-bruster" \
  --node "$(command -v node)" --chrome "$BENCH_CHROME" --shell "$BENCH_SHELL" --deps "$DEPS" \
  --rounds 5 --iterations 10 --tools bruster --output "$OUT/compare-baseline" > "$OUT/compare-baseline.log" 2>&1
for version in candidate baseline; do
  binary="$ROOT/final/candidate-bruster"
  if [ "$version" = baseline ]; then binary="$ROOT/baseline-bruster"; fi
  bwrap --dev-bind / / --overlay-src /usr --overlay-src "$BRUSTER_DEPS/usr" --ro-overlay /usr \
    python3 -B "$HARNESS/bench_footprint.py" --bruster "$binary" --node "$(command -v node)" \
    --chrome "$BENCH_CHROME" --shell "$BENCH_SHELL" --deps "$DEPS" \
    --samples "$OUT/compare-$version/samples.json" --output "$OUT/footprint-$version.json" \
    > "$OUT/footprint-$version.log" 2>&1
done
PYTHONPATH="$HARNESS" python3 -B - <<'PY'
import json
from pathlib import Path
import bench_report
root = Path('benchmarks/results/implementation/clean')
for version in ['candidate', 'baseline']:
    data = json.loads((root / f'compare-{version}/summary.json').read_text())
    rows = json.loads((root / f'compare-{version}/samples.json').read_text())
    footprint = json.loads((root / f'footprint-{version}.json').read_text())
    if version == 'candidate':
        bench_report.validate(data['metadata'], rows, footprint)
    assert all(not row[key] for row in rows for key in ['competing_before', 'competing_at_memory', 'competing_after', 'cleanup_forced_processes'])
    assert all(sample['complete'] for row in rows for sample in row['idle_memory'])
print('Clean paired probes, comparisons, and complete runtime inventories validated.')
PY
