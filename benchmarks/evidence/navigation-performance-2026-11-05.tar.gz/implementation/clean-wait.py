"""Wait read-only for the separate campaign, then require two quiet minutes."""
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / 'clean/harness'))
from bench_compare import background_work

completion = Path('/home/admin/Projects/.bruster-build/website-compatibility-1000/benchmarks/results/websites-1000/campaign-completion.json')
quiet_since = None
print('Waiting for the external website campaign to complete; no external processes are modified.', flush=True)
while True:
    try:
        campaign = json.loads(completion.read_text())
    except (OSError, ValueError):
        campaign = {}
    if campaign.get('complete') and campaign.get('domains') == 1000 and not background_work():
        if quiet_since is None:
            quiet_since = time.monotonic()
        if time.monotonic() - quiet_since >= 120:
            record = {'checked_utc': datetime.now(timezone.utc).isoformat(),
                      'external_completion': campaign, 'quiet_seconds': 120,
                      'competing_processes': background_work()}
            if not record['competing_processes']:
                (Path(__file__).parent / 'clean/scheduling.json').write_text(json.dumps(record, indent=2) + '\n')
                print('Campaign complete; two quiet minutes observed.', flush=True)
                break
    else:
        quiet_since = None
    time.sleep(10)
