"""Verify the idle desktop daemon outside the measurement user namespace."""
import datetime
import json
import os
import time
from pathlib import Path

allowed = {'/usr/bin/xscreensaver', '/usr/libexec/xscreensaver/xscreensaver-systemd'}
record = {'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'monotonic': time.monotonic(), 'processes': {},
          'cpu_budget': 'Each approved PID may consume at most 0.05 CPU seconds plus 0.5% of elapsed wall time after this preflight; sleeping state and no unapproved descendants required at each workload check.'}
for path in Path('/proc').glob('[0-9]*'):
    try:
        if not (path / 'comm').read_text().startswith('xscreensaver'):
            continue
        executable = str((path / 'exe').resolve(strict=True))
        if executable not in allowed:
            continue
        fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
        assert fields[0] == 'S', 'Desktop daemon is active'
        record['processes'][path.name] = {'exe': executable, 'start': fields[19],
            'cpu_seconds': (int(fields[11]) + int(fields[12])) / os.sysconf('SC_CLK_TCK'),
            'stat': (path / 'stat').read_text(), 'status': (path / 'status').read_text()}
    except (FileNotFoundError, ProcessLookupError):
        continue
Path(os.environ['BRUSTER_BENCH_IDLE_DESKTOP']).write_text(json.dumps(record, indent=2) + '\n')
