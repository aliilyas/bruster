import datetime
import hashlib
import json
import os
import shutil
import urllib.error
import urllib.request
from pathlib import Path

root, out, deps = (Path(os.environ[k]) for k in ('BENCH_ROOT', 'BENCH_OUT', 'BENCH_DEPS'))
assert not list(out.glob('paired-*.json')), 'Do not overwrite retained measurements'
provenance = json.loads((out / 'provenance.json').read_text())
for name, expected in provenance['binary_sha256'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
for name, expected in provenance['harness_sha256'].items():
    assert hashlib.sha256((out / provenance['harness_directory'] / name).read_bytes()).hexdigest() == expected, name
versions = {'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'packages': {}}
for name in ('playwright', 'playwright-core', 'puppeteer', 'puppeteer-core', 'agent-browser'):
    with urllib.request.urlopen(f'https://registry.npmjs.org/{name}/latest', timeout=30) as response:
        remote = json.load(response)
    local_path = deps / 'node_modules' / name / 'package.json'
    local = json.loads(local_path.read_text())['version'] if local_path.exists() else None
    versions['packages'][name] = {'latest': remote['version'], 'installed': local, 'integrity': remote['dist']['integrity']}
    if local is not None:
        assert local == remote['version'], f'Update {name} before measuring'
    if name == 'playwright':
        required = remote['dependencies']['playwright-core']
        versions['playwright_required_core'] = required
        try:
            with urllib.request.urlopen(f'https://registry.npmjs.org/playwright-core/{required}', timeout=30) as response:
                core = json.load(response)
            installed_core = json.loads((deps / 'node_modules/playwright-core/package.json').read_text())['version']
            assert installed_core == core['version'], 'New Playwright core is installable; update before measuring'
        except urllib.error.HTTPError as exc:
            assert exc.code == 404
            versions['playwright_release_exception'] = {'required_core_http_status': exc.code, 'body': exc.read().decode(),
                'note': 'Latest wrapper requires an unpublished core. Measure the latest installable core and disclose this explicitly.'}
versions['playwright_browsers'] = json.loads((deps / 'node_modules/playwright-core/browsers.json').read_text())
versions['selected_browsers'] = json.loads((deps / 'browser-versions.json').read_text())
(out / 'latest-versions.json').write_text(json.dumps(versions, indent=2) + '\n')
for name in ('package.json', 'package-lock.json', 'browser-versions.json', 'browser-paths.env', 'install-browsers.mjs', 'install-browsers.py', 'chrome-download-manifest.json'):
    shutil.copy2(deps / name, out / name)
print('Frozen binary/harness hashes and latest installable competitor versions verified.', flush=True)
