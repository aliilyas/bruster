"""Check the narrow desktop exception on the host and inside the user namespace."""
import copy
import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch
import bench_compare

record = json.loads(Path(os.environ['BRUSTER_BENCH_IDLE_DESKTOP']).read_text())
pid = int(next(p for p, row in record['processes'].items() if row['exe'] == '/usr/bin/xscreensaver'))
table = bench_compare.process_table()
assert bench_compare.idle_desktop_controller(pid, table)
assert pid not in {r['pid'] for r in bench_compare.background_work()}
with tempfile.TemporaryDirectory(dir='/tmp/opencode') as directory:
    path = Path(directory) / 'desktop.json'
    with patch.dict(os.environ, BRUSTER_BENCH_IDLE_DESKTOP=str(path)):
        changed = copy.deepcopy(record)
        changed['processes'][str(pid)]['start'] = '0'
        path.write_text(json.dumps(changed))
        assert not bench_compare.idle_desktop_controller(pid, table), 'PID reuse must reject'
        changed = copy.deepcopy(record)
        changed['processes'][str(pid)]['cpu_seconds'] -= 1000
        path.write_text(json.dumps(changed))
        assert not bench_compare.idle_desktop_controller(pid, table), 'CPU activity must reject'
        path.write_text(json.dumps(record))
        changed_table = dict(table)
        changed_table[99999999] = {'parent': pid, 'start': '1', 'state': 'S'}
        assert not bench_compare.idle_desktop_controller(pid, changed_table), 'Unapproved descendant must reject'
        with patch.dict(os.environ, BRUSTER_BENCH_IDLE_DESKTOP=''):
            assert not bench_compare.idle_desktop_controller(pid, table), 'Exception must be opt-in'
print('Five idle-desktop identity, CPU, descendant and opt-in checks passed.')
