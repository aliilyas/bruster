"""Package retained measurement evidence, excluding installed dependency caches."""
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent.parent
repo = root.parents[2]
destination = repo / 'benchmarks/evidence/navigation-performance-2026-11-05.tar.gz'
assert (root / 'clean-2026-11-05/validation.json').is_file()
assert (root / 'clean-2026-11-05/report-summary.json').is_file()
assert not destination.exists(), 'Never replace published evidence'
paths = sorted(p for p in root.rglob('*') if p.is_file()
               and not any(part.startswith('deps-') or part == '__pycache__' for part in p.relative_to(root).parts)
               and p.name != 'EVIDENCE_MANIFEST.json')
manifest = {'algorithm': 'sha256', 'root': 'implementation',
            'final_batch': 'clean-2026-11-05',
            'historical_and_excluded_batches': 'See MEASUREMENT_STATUS.md; historical, cancelled and contaminated evidence is retained.',
            'exclusions': 'Installed npm/browser dependency trees and caches; exact lockfiles, browser URLs, hashes and manifests are included.',
            'files': {str(p.relative_to(root)): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths}}
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
(root / 'EVIDENCE_MANIFEST.json').write_bytes(manifest_bytes)
destination.parent.mkdir(parents=True, exist_ok=True)
with destination.open('wb') as stream, gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w', dereference=True) as archive:
        for path in paths:
            info = archive.gettarinfo(str(path), arcname='implementation/' + str(path.relative_to(root)))
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            info.mtime = 0
            with path.open('rb') as data:
                archive.addfile(info, data)
        info = tarfile.TarInfo('implementation/EVIDENCE_MANIFEST.json')
        info.size, info.mode = len(manifest_bytes), 0o644
        archive.addfile(info, io.BytesIO(manifest_bytes))
with tarfile.open(destination, 'r:gz') as archive:
    members = {m.name: m for m in archive.getmembers()}
    assert len(members) == len(paths) + 1
    for name, expected in manifest['files'].items():
        contents = archive.extractfile(members['implementation/' + name]).read()
        assert len(contents) == expected['bytes']
        assert hashlib.sha256(contents).hexdigest() == expected['sha256'], name
digest = hashlib.sha256(destination.read_bytes()).hexdigest()
destination.with_suffix(destination.suffix + '.sha256').write_text(f'{digest}  {destination.name}\n')
print(json.dumps({'path': str(destination.relative_to(repo)), 'bytes': destination.stat().st_size,
                  'sha256': digest, 'files': len(paths) + 1}, indent=2))
