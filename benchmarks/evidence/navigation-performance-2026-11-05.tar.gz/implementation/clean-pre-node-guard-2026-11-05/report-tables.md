| Paired metric | Baseline | Candidate | Change |
|---|---:|---:|---:|
| launch_to_page_ms | 955.14 [908.49–1111.24] | 370.18 [314.81–671.22] | -61.2% |
| ready_ms | 319.13 [270.14–425.71] | 190.96 [179.12–444.87] | -40.2% |
| first_navigation_ms | 641.57 [622.64–684.75] | 154.14 [129.32–222.80] | -76.0% |
| warm_navigation_ms | 15.10 [9.72–22.55] | 14.23 [8.07–22.84] | -5.8% |
| graphics_pss_mib | 240.70 [238.68–240.81] | 202.78 [201.64–203.43] | -15.8% |
| graphics_screenshot_ms | 48.27 [43.93–50.65] | 38.55 [37.51–41.01] | -20.1% |
| live_object_ms | 10.35 [8.36–13.49] | 9.54 [5.86–18.60] | -7.8% |
| live_string_ms | 8.46 [6.72–10.88] | 8.41 [6.05–13.28] | -0.7% |
| cached_object_ms | 3.85 [2.81–5.94] | 2.26 [1.53–4.04] | -41.4% |
| cached_string_ms | 3.67 [2.70–4.92] | 2.53 [1.70–4.65] | -31.0% |
| stress_object_ms | 35.47 [30.09–124.73] | 14.13 [12.01–16.53] | -60.2% |

| Configuration | Launch → page (ms) | Warm tiny navigation (ms) | Large extraction (ms) | PSS + display (MiB) | Installed runtime (MB) |
|---|---:|---:|---:|---:|---:|
| bruster | 305.15 [280.44–346.19] | 7.77 [5.47–21.73] | 23.25 [6.51–160.38] | 190.81 [187.44–197.55] | 442.47 |
| playwright | 1527.37 [1377.57–1866.42] | 23.76 [16.93–51.33] | 138.71 [101.03–185.90] | 491.73 [467.99–493.42] | 659.02 |
| puppeteer | 1598.44 [1504.52–1739.08] | 22.96 [17.91–31.40] | 38.38 [19.57–79.02] | 405.61 [401.80–407.02] | 672.88 |
| agent-browser | 4276.57 [4190.90–4380.38] | 33.02 [26.54–67.58] | 38.06 [31.59–72.92] | 480.18 [477.06–481.67] | 535.33 |
| playwright-shell | 1211.58 [1087.50–1225.41] | 14.99 [10.82–42.72] | 132.47 [103.75–216.84] | 332.74 [328.39–333.93] | 455.18 |

Timers:
{
  "baseline": [
    {
      "completed": 0,
      "threads": 23,
      "parent_virtual_mib": 72639.3125,
      "parent_rss_mib": 171.8984375,
      "total_pss_mib": 226.529296875,
      "elapsed_s": 5.031000000599306e-06
    },
    {
      "completed": 50,
      "threads": 73,
      "parent_virtual_mib": 73508.09375,
      "parent_rss_mib": 172.81640625,
      "total_pss_mib": 237.853515625,
      "elapsed_s": 0.8410485019999214
    },
    {
      "completed": 100,
      "threads": 123,
      "parent_virtual_mib": 73608.9140625,
      "parent_rss_mib": 173.58203125,
      "total_pss_mib": 236.388671875,
      "elapsed_s": 1.7307017190000806
    },
    {
      "completed": 150,
      "threads": 173,
      "parent_virtual_mib": 73709.6953125,
      "parent_rss_mib": 174.25,
      "total_pss_mib": 238.943359375,
      "elapsed_s": 2.703738956000052
    },
    {
      "completed": 200,
      "threads": 223,
      "parent_virtual_mib": 73810.4765625,
      "parent_rss_mib": 174.921875,
      "total_pss_mib": 243.126953125,
      "elapsed_s": 3.623369532000197
    }
  ],
  "candidate": [
    {
      "completed": 0,
      "threads": 18,
      "parent_virtual_mib": 72118.5234375,
      "parent_rss_mib": 138.92578125,
      "total_pss_mib": 188.2939453125,
      "elapsed_s": 2.485000095475698e-06
    },
    {
      "completed": 50,
      "threads": 18,
      "parent_virtual_mib": 72118.5234375,
      "parent_rss_mib": 139.18359375,
      "total_pss_mib": 199.7509765625,
      "elapsed_s": 0.750153156000124
    },
    {
      "completed": 100,
      "threads": 18,
      "parent_virtual_mib": 72118.5625,
      "parent_rss_mib": 139.42578125,
      "total_pss_mib": 198.8876953125,
      "elapsed_s": 1.5039510940000582
    },
    {
      "completed": 150,
      "threads": 18,
      "parent_virtual_mib": 72118.5625,
      "parent_rss_mib": 139.5078125,
      "total_pss_mib": 199.8681640625,
      "elapsed_s": 2.3100384750000558
    },
    {
      "completed": 200,
      "threads": 18,
      "parent_virtual_mib": 72118.5625,
      "parent_rss_mib": 139.609375,
      "total_pss_mib": 200.8330078125,
      "elapsed_s": 3.2290752740000244
    }
  ]
}
